document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("searchInput");
    const searchButton = document.getElementById("searchButton");
    const loadAllButton = document.getElementById("loadAll");
    const resultsContainer = document.getElementById("results");
    const downloadAppLink = document.getElementById("download-app");

    let searchTimeout;
    let currentPage = 1;
    let currentCategory = "people";

    // Inicializar la lista de favoritos
    renderFavoritesList();

    // Configurar el enlace de descarga de la app
    downloadAppLink.href = "https://drive.google.com/..."; // Reemplazar con el link real

    async function performSearch() {
        const name = searchInput.value.trim();
        
        if (name === "") {
            clearResults();
            return;
        }

        showLoadingIndicator(true);

        const people = await fetchData("people", name);
        const starships = await fetchData("starships", name);

        showLoadingIndicator(false);

        if (people.results.length === 0 && starships.results.length === 0) {
            clearResults();
            return;
        }

        const results = people.results.length > 0 ? { items: people.results, type: "people" } : { items: starships.results, type: "starships" };
        saveToLocalStorage("lastSearch", results);
        saveSearchToHistory(name);
        renderResults(results.items, results.type);
    }

    async function loadAllItems(category) {
        showLoadingIndicator(true);
        currentCategory = category;
        currentPage = 1;
        
        const data = await fetchData(category, "", currentPage);
        
        if (data && data.results) {
            renderResults(data.results, category);
            renderPagination(data.count, category);
        }
        
        showLoadingIndicator(false);
    }

    async function loadPage(page, category) {
        showLoadingIndicator(true);
        currentPage = page;
        
        const data = await fetchData(category, "", currentPage);
        
        if (data && data.results) {
            renderResults(data.results, category);
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
        
        showLoadingIndicator(false);
    }

    function renderPagination(totalItems, category) {
        const itemsPerPage = 10;
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        const pagination = document.createElement("div");
        pagination.className = "pagination";
        
        if (totalPages > 1) {
            // Botón Anterior
            if (currentPage > 1) {
                const prevButton = document.createElement("button");
                prevButton.innerHTML = "<i class='fas fa-chevron-left'></i>";
                prevButton.addEventListener("click", () => loadPage(currentPage - 1, category));
                pagination.appendChild(prevButton);
            }
            
            // Números de página
            for (let i = 1; i <= totalPages; i++) {
                const pageButton = document.createElement("button");
                pageButton.textContent = i;
                if (i === currentPage) {
                    pageButton.style.background = "#ffdb4d";
                }
                pageButton.addEventListener("click", () => loadPage(i, category));
                pagination.appendChild(pageButton);
            }
            
            // Botón Siguiente
            if (currentPage < totalPages) {
                const nextButton = document.createElement("button");
                nextButton.innerHTML = "<i class='fas fa-chevron-right'></i>";
                nextButton.addEventListener("click", () => loadPage(currentPage + 1, category));
                pagination.appendChild(nextButton);
            }
            
            resultsContainer.appendChild(pagination);
        }
    }

    searchInput.addEventListener("input", () => {
        clearTimeout(searchTimeout);

        if (searchInput.value.trim() === "") {
            clearResults();
            return;
        }

        searchTimeout = setTimeout(performSearch, 500);
    });

    searchInput.addEventListener("keypress", (event) => {
        if (event.key === "Enter") {
            performSearch();
        }
    });

    searchButton.addEventListener("click", performSearch);

    loadAllButton.addEventListener("click", () => {
        const category = confirm("¿Qué deseas cargar?\nAceptar para Personajes, Cancelar para Naves") ? "people" : "starships";
        loadAllItems(category);
    });

    document.getElementById("showFavorites").addEventListener("click", () => {
        document.getElementById("favorites-sidebar").classList.toggle("visible");
    });
    
    document.getElementById("showHistory").addEventListener("click", showSearchHistory);
    document.getElementById("toggleDarkMode").addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
    });

    handleOfflineMode();

    function showLoadingIndicator(show) {
        if (show) {
            resultsContainer.innerHTML = "<p class='loading'><i class='fas fa-spinner fa-spin'></i> Cargando resultados...</p>";
        } else {
            resultsContainer.innerHTML = "";
        }
    }

    function clearResults() {
        resultsContainer.innerHTML = "";
    }
});

// Función para guardar en LocalStorage
function saveToLocalStorage(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// Función para cargar desde LocalStorage
function loadFromLocalStorage(key) {
    return JSON.parse(localStorage.getItem(key)) || [];
}

// Función para guardar en el historial de búsqueda
function saveSearchToHistory(searchTerm) {
    let history = loadFromLocalStorage("searchHistory");
    if (!history.includes(searchTerm)) {
        history.push(searchTerm);
        saveToLocalStorage("searchHistory", history);
    }
}
