function saveSearchToHistory(name) {
    let history = loadFromLocalStorage("searchHistory") || [];
    history.unshift(name);
    saveToLocalStorage("searchHistory", history.slice(0, 10));
}

function showSearchHistory() {
    const history = loadFromLocalStorage("searchHistory") || [];
    alert("Historial de búsqueda: " + (history.length ? history.join(", ") : "No hay búsquedas recientes."));
}

// Exponer función globalmente
window.showSearchHistory = showSearchHistory;