function renderResults(items, type) {
    const results = document.getElementById("results");
    results.innerHTML = "";
    
    if (!items || items.length === 0) {
        results.innerHTML = "<p>No se encontraron resultados</p>";
        return;
    }

    items.forEach(item => {
        const card = document.createElement("div");
        card.classList.add("character-card");
        
        const id = extractIdFromUrl(item.url);
        const imageUrl = getImageUrl(type, id);
        
        let content = `
            <div class="image-container">
                <img src="${imageUrl}" 
                     onerror="this.onerror=null;this.src='https://via.placeholder.com/300x200?text=Imagen+no+disponible'" 
                     alt="${item.name}"
                     loading="lazy">
            </div>
            <h3>${item.name}</h3>
        `;
        
        if (type === "people") {
            content += `<p><i class="fas fa-ruler-vertical"></i> Altura: ${item.height} cm</p>
                       <p><i class="fas fa-weight"></i> Peso: ${item.mass} kg</p>`;
        } else if (type === "starships") {
            content += `<p><i class="fas fa-space-shuttle"></i> Modelo: ${item.model}</p>
                       <p><i class="fas fa-industry"></i> Fabricante: ${item.manufacturer}</p>`;
        }

        content += `
            <button class="favorite-btn" onclick="event.stopPropagation(); addToFavorites(${JSON.stringify(item).replace(/"/g, '&quot;')}, '${type}')">
                <i class="fas fa-star"></i> Favorito
            </button>
        `;
        
        card.innerHTML = content;
        
        card.addEventListener("click", () => {
            showItemDetails(item, type);
        });
        
        results.appendChild(card);
    });
}

window.renderResults = renderResults;