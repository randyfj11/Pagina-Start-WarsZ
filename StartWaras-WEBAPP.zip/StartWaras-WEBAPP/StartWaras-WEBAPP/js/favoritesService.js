// En favoritesService.js - Modifica addToFavorites
function addToFavorites(item, type) {
    let favorites = loadFromLocalStorage("favorites") || [];
    
    // Extraer el ID correctamente
    const id = extractIdFromUrl(item.url);
    
    // Verificar si ya existe
    const exists = favorites.some(fav => fav.name === item.name && fav.type === type);
    
    if (!exists) {
        favorites.push({
            name: item.name,
            type: type,
            id: id,
            data: item
        });
        saveToLocalStorage("favorites", favorites);
        renderFavoritesList();
        alert(`${item.name} añadido a favoritos!`);
    } else {
        alert(`${item.name} ya está en favoritos!`);
    }
}

function removeFromFavorites(name) {
    let favorites = loadFromLocalStorage("favorites") || [];
    favorites = favorites.filter(fav => fav.name !== name);
    saveToLocalStorage("favorites", favorites);
    renderFavoritesList();
}

function renderFavoritesList() {
    const favorites = loadFromLocalStorage("favorites") || [];
    const favoritesList = document.getElementById("favorites-list");
    
    favoritesList.innerHTML = "";
    
    if (favorites.length === 0) {
        favoritesList.innerHTML = "<p>No tienes favoritos aún.</p>";
        return;
    }
    
    favorites.forEach(fav => {
        const favElement = document.createElement("div");
        favElement.className = "favorite-card";
        favElement.innerHTML = `
            <span>${fav.name}</span>
            <button onclick="removeFromFavorites('${fav.name}')"><i class="fas fa-times"></i></button>
        `;
        
        favElement.addEventListener("click", () => {
            showItemDetails(fav.data, fav.type);
        });
        
        favoritesList.appendChild(favElement);
    });
}

// Exponer funciones globalmente
window.addToFavorites = addToFavorites;
window.removeFromFavorites = removeFromFavorites;
window.renderFavoritesList = renderFavoritesList;