const API_BASE = "https://swapi.dev/api/";
const IMAGE_BASE = "https://starwars-visualguide.com/assets/img/";

async function fetchData(category, name = "", page = 1) {
    try {
        let url = `${API_BASE}${category}/`;
        if (name) {
            url += `?search=${name}`;
        } else {
            url += `?page=${page}`;
        }
        
        const response = await fetch(url);
        if (!response.ok) throw new Error("API no disponible");
        const data = await response.json();
        return data;
    } catch (error) {
        console.error(error);
        return null;
    }
}

function getImageUrl(category, id) {
    if (!id) return 'https://via.placeholder.com/300x200?text=Imagen+no+disponible';
    
    const categoryMap = {
        people: 'characters',
        starships: 'starships',
        vehicles: 'vehicles',
        planets: 'planets',
        films: 'films',
        species: 'species'
    };
    
    const imageCategory = categoryMap[category] || category;
    return `${IMAGE_BASE}${imageCategory}/${id}.jpg`;
}

function extractIdFromUrl(url) {
    if (!url) return null;
    
    // Extrae el ID de la URL (ej: "https://swapi.dev/api/people/1/" → "1")
    const idPattern = /\/(\d+)\/$/;
    const match = url.match(idPattern);
    
    return match ? match[1] : null;
}

window.fetchData = fetchData;
window.getImageUrl = getImageUrl;
window.extractIdFromUrl = extractIdFromUrl;